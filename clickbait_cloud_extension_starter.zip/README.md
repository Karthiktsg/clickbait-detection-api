# Clickbait Detector — Cloud API + Chrome Extension

This package wraps the **same DistilBERT + KL-regularized attention architecture** used in your notebook in a cloud API and a Chrome Manifest V3 extension.

## Architecture
Chrome extension (active tab headlines) → HTTPS FastAPI `/predict` endpoint → DistilBERT + KL-trained checkpoint → label, confidence, attention tokens, rationale.

## 1. Export your trained model from Colab
Run this **after the notebook has trained and selected `best_model.pt`**. Your notebook saves artifacts under `./clickbait_project/config/`.

```python
from google.colab import drive
drive.mount('/content/drive')

# If BASE_PATH is ./clickbait_project in the current Colab runtime:
!cd clickbait_project && zip -r /content/clickbait_model_artifacts.zip config/best_model.pt config/tokenizer config/trigger_lexicon.json
```

Download `clickbait_model_artifacts.zip`, extract it, and copy these into `backend/artifacts/`:
- `best_model.pt`
- the full `tokenizer/` directory
- `trigger_lexicon.json`

Expected:
```
backend/artifacts/
  best_model.pt
  trigger_lexicon.json
  tokenizer/
    tokenizer_config.json
    special_tokens_map.json
    vocab.txt
    tokenizer.json
    ...
```
The tokenizer files can vary slightly; keep all files saved by `tokenizer.save_pretrained()`.

> The notebook itself does not contain the trained weights. The API will not make real predictions until you copy in `best_model.pt` and the tokenizer files.

## 2. Run the API locally
From this folder:

```bash
cd backend
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000
```
Open `http://localhost:8000/health` to check readiness and `http://localhost:8000/docs` for interactive API docs.

Test:
```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d "{\"headline\":\"You won't believe what happened next!\"}"
```

## 3. Configure and test the Chrome extension
1. Open `chrome://extensions`.
2. Enable **Developer mode**.
3. Select **Load unpacked** and choose the `extension/` folder.
4. Open `extension/config.js` and set `API_BASE_URL` to your API URL. For local testing use `http://localhost:8000`; for deployment use your HTTPS service URL.
5. Open a news page and click the extension icon, then choose **Scan this page**.

The extension sends headline text to your API. It does not send the full page HTML.

## 4. Deploy the API to a cloud host
This package includes a Dockerfile. Deploy `backend/` as a Docker web service on a host that supports Python containers (for example, Google Cloud Run, Hugging Face Spaces Docker, or Render).

- Build context: `backend/`
- Container listens on port `8000` (Cloud Run provides `PORT`; the included command uses it).
- Set environment variable `ALLOWED_ORIGINS` to `chrome-extension://*` only if your host accepts wildcard origin matching; otherwise use `*` for initial testing and restrict it after testing.
- For Chrome extensions, CORS may not be the only access check; keep the API public only if that is intended.
- Add the model artifacts to `backend/artifacts/` for a simple first deployment. Do not commit private datasets or credentials.
- Model weights increase the container size. For larger deployments, store artifacts in object storage and download them during startup.

## Important notes
- The endpoint uses the model architecture and label mapping in your notebook: `0 = NOT CLICKBAIT`, `1 = CLICKBAIT`.
- Attention weights are returned as model attention-based signals, not proof that a token caused the prediction.
- Do not expose training data, checkpoints, or secrets in the extension.
