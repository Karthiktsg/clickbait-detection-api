import os
from contextlib import asynccontextmanager
from typing import List

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from model_service import get_predictor

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Load once at startup; fail clearly if model artifacts have not been added.
    try:
        get_predictor()
        app.state.model_ready = True
    except Exception as exc:
        app.state.model_ready = False
        app.state.startup_error = str(exc)
    yield

app = FastAPI(
    title="Clickbait Detection API",
    description="DistilBERT with KL-regularized attention from the project notebook.",
    version="1.0.0",
    lifespan=lifespan,
)

origins = os.getenv("ALLOWED_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[x.strip() for x in origins],
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)

class PredictRequest(BaseModel):
    headline: str = Field(min_length=1, max_length=1000)

class BatchRequest(BaseModel):
    headlines: List[str] = Field(min_length=1, max_length=30)

@app.get("/")
def root():
    return {"service": "Clickbait Detection API", "docs": "/docs", "health": "/health"}

@app.get("/health")
def health():
    try:
        get_predictor()
        return {"status": "ok", "model_loaded": True}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))

@app.post("/predict")
def predict(request: PredictRequest):
    try:
        return get_predictor().predict(request.headline)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Prediction unavailable: {exc}")

@app.post("/predict-batch")
def predict_batch(request: BatchRequest):
    try:
        predictor = get_predictor()
        results = []
        for headline in request.headlines:
            if headline.strip():
                results.append(predictor.predict(headline))
        return {"results": results}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Batch prediction unavailable: {exc}")
