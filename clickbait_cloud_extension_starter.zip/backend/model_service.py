import json
import os
import re
from pathlib import Path

import torch
import torch.nn as nn
from transformers import DistilBertModel, DistilBertTokenizerFast

BASE = Path(__file__).resolve().parent / "artifacts"
MODEL_NAME = "distilbert-base-uncased"
MAX_LENGTH = 64


class AttentionRegularizedDistilBert(nn.Module):
    """Inference architecture matching the uploaded notebook."""
    def __init__(self, dropout: float = 0.3):
        super().__init__()
        self.bert = DistilBertModel.from_pretrained(
            MODEL_NAME, attn_implementation="eager"
        )
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Linear(self.bert.config.hidden_size, 2)

    def forward(self, input_ids, attention_mask):
        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            output_attentions=True,
        )
        cls_embedding = outputs.last_hidden_state[:, 0, :]
        logits = self.classifier(self.dropout(cls_embedding))
        attn_dist = outputs.attentions[-1].mean(dim=1)[:, 0, :]
        return logits, attn_dist


class ClickbaitPredictor:
    def __init__(self):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        weights = BASE / "best_model.pt"
        tokenizer_dir = BASE / "tokenizer"
        if not weights.exists() or not (tokenizer_dir / "tokenizer.json").exists():
            raise RuntimeError(
                "Model artifacts missing. Copy best_model.pt and the full tokenizer/ "
                "directory into backend/artifacts/. See README.md."
            )
        self.tokenizer = DistilBertTokenizerFast.from_pretrained(str(tokenizer_dir))
        self.model = AttentionRegularizedDistilBert().to(self.device)
        state = torch.load(weights, map_location=self.device, weights_only=True)
        self.model.load_state_dict(state)
        self.model.eval()
        lexicon_path = BASE / "trigger_lexicon.json"
        self.lexicon = json.loads(lexicon_path.read_text(encoding="utf-8")) if lexicon_path.exists() else {}
        self.flat_triggers = {
            word.lower(): category
            for category, words in self.lexicon.items()
            for word in words if " " not in word
        }
        self.category_labels = {
            "curiosity_phrases": "creates a curiosity gap",
            "superlatives": "uses exaggerated/superlative language",
            "intensifiers": "uses intensifying language",
            "absolute_terms": "uses absolute/sweeping claims",
        }

    @torch.inference_mode()
    def predict(self, headline: str):
        headline = headline.strip()
        if not headline:
            raise ValueError("Headline must not be empty.")
        encoding = self.tokenizer(
            headline, add_special_tokens=True, max_length=MAX_LENGTH,
            padding="max_length", truncation=True, return_tensors="pt"
        )
        input_ids = encoding["input_ids"].to(self.device)
        attention_mask = encoding["attention_mask"].to(self.device)
        logits, attention = self.model(input_ids, attention_mask)
        probs = torch.softmax(logits, dim=1)[0]
        label = int(torch.argmax(probs).item())
        seq_len = int(attention_mask.sum().item())
        tokens = self.tokenizer.convert_ids_to_tokens(input_ids[0][:seq_len])
        weights = attention[0][:seq_len].detach().cpu().tolist()
        ranked = sorted(
            [(t, w) for t, w in zip(tokens, weights)
             if t not in ("[CLS]", "[SEP]", "[PAD]")],
            key=lambda x: x[1], reverse=True
        )[:3]
        if label == 0:
            rationale = (
                f"Predicted NOT CLICKBAIT ({probs[label].item():.1%}). "
                "No single token or category dominated attention."
            )
        else:
            top_tokens = [t for t, _ in ranked]
            matched = {
                self.flat_triggers[t.lstrip("#").lower()]
                for t in top_tokens if t.lstrip("#").lower() in self.flat_triggers
            }
            detail = (
                " (" + "; ".join(self.category_labels.get(c, c) for c in matched) + ")"
                if matched else ""
            )
            rationale = (
                f"Predicted CLICKBAIT ({probs[label].item():.1%}). "
                f"Highest-attention tokens: {', '.join(top_tokens)}{detail}. "
                "These are the tokens the KL-regularized attention weighted most heavily."
            )
        return {
            "headline": headline,
            "label": "CLICKBAIT" if label == 1 else "NOT CLICKBAIT",
            "pred_label": label,
            "confidence": float(probs[label].item()),
            "rationale": rationale,
            "tokens": tokens,
            "attention": [float(x) for x in weights],
        }


_predictor = None

def get_predictor():
    global _predictor
    if _predictor is None:
        _predictor = ClickbaitPredictor()
    return _predictor
