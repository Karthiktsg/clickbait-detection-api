// Extract likely headlines from the active page. No page HTML is sent to the API.
(() => {
  const selectors = ["h1", "h2", "article h3", "[role='heading']"];
  const unique = new Set();
  for (const el of document.querySelectorAll(selectors.join(","))) {
    const text = (el.innerText || el.textContent || "").trim().replace(/\s+/g, " ");
    if (text.length >= 10 && text.length <= 300) unique.add(text);
    if (unique.size >= 30) break;
  }
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === "GET_HEADLINES") {
      sendResponse({ headlines: Array.from(unique) });
    }
    return true;
  });
})();
