const scanButton = document.getElementById("scan");
const statusEl = document.getElementById("status");
const resultsEl = document.getElementById("results");

function showStatus(text, isError = false) {
  statusEl.textContent = text;
  statusEl.className = isError ? "error" : "";
}
function addResult(item) {
  const card = document.createElement("article");
  card.className = `item ${item.pred_label === 1 ? "clickbait" : "not-clickbait"}`;
  const title = document.createElement("strong");
  title.textContent = item.headline;
  const label = document.createElement("div");
  label.textContent = `${item.label} · ${(item.confidence * 100).toFixed(1)}% confidence`;
  const rationale = document.createElement("div");
  rationale.textContent = item.rationale;
  const meta = document.createElement("div");
  meta.className = "meta";
  meta.textContent = "Top attention tokens: " + item.tokens
    .map((t, i) => ({t, w: item.attention[i]}))
    .filter(x => !["[CLS]", "[SEP]", "[PAD]"].includes(x.t))
    .sort((a,b) => b.w - a.w).slice(0,3).map(x => x.t).join(", ");
  card.append(title, label, rationale, meta);
  resultsEl.appendChild(card);
}

scanButton.addEventListener("click", async () => {
  resultsEl.replaceChildren();
  scanButton.disabled = true;
  showStatus("Finding headlines…");
  try {
    const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
    if (!tab?.id || !/^https?:/.test(tab.url || "")) {
      throw new Error("Open a regular news/article webpage first.");
    }
    let response;
    try {
      response = await chrome.tabs.sendMessage(tab.id, {type: "GET_HEADLINES"});
    } catch {
      throw new Error("Refresh the webpage and try again.");
    }
    const headlines = response?.headlines || [];
    if (!headlines.length) throw new Error("No suitable headlines found on this page.");
    showStatus(`Checking ${headlines.length} headline(s)…`);
    const apiResponse = await fetch(`${API_BASE_URL}/predict-batch`, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({headlines})
    });
    if (!apiResponse.ok) {
      const body = await apiResponse.json().catch(() => ({}));
      throw new Error(body.detail || `API error (${apiResponse.status}).`);
    }
    const data = await apiResponse.json();
    (data.results || []).forEach(addResult);
    showStatus(`Finished: ${(data.results || []).length} headline(s) checked.`);
  } catch (err) {
    showStatus(err.message || "Something went wrong.", true);
  } finally {
    scanButton.disabled = false;
  }
});
